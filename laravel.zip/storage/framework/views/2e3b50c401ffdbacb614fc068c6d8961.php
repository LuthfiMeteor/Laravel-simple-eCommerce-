<?php $__env->startSection('title'); ?>
    Category
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h4>Semua Kategori</h4>
                    <div class="row">
                    <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3 mb-3">
                        <a href="<?php echo e(url('lihat-kategori/'.$cate->slug)); ?>" class="text-dark text-decoration-none">
                        <div class="card border-0">
                        <img src="<?php echo e(asset('asset/upload/kategori/'.$cate->image)); ?>" alt="category">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($cate->nama); ?></h5>
                            <p>
                                <?php echo e($cate->deskripsi); ?>

                            </p>
                        </div>
                    </div>
                </a>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/luthfimeteor/lks_toko/toko/resources/views/frontend/category.blade.php ENDPATH**/ ?>