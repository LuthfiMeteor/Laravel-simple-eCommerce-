<?php $__env->startSection('title'); ?>
    LKS_TOKO
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    
    <div class="py-5">
        <div class="container">
            <?php echo $__env->make('partial.frontcarousel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="row mt-2">
                <h2>Feature</h2>
                    <div class="owl-carousel owl-theme">
                        <?php $__currentLoopData = $trending; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ngetrend): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card border-0">
                        <img src="<?php echo e(asset('asset/upload/produk/'.$ngetrend->image)); ?>" alt="Produk">
                        <div class="card-body">
                            <h5><?php echo e($ngetrend->nama); ?></h5>
                            <span class="float-start">Rp. <?php echo e($ngetrend->harga_jual); ?></span>
                            <span class="float-end text-danger"><s>Rp.<?php echo e($ngetrend->original_harga); ?></s></span>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                
            </div>
        </div>
    </div>

    <div class="py-5">
        <div class="container">
            <div class="row">
                <h2>Trending Category</h2>
                    <div class="owl-carousel owl-theme">
                        <?php $__currentLoopData = $trending_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trend_kate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(url('lihat-kategori/'.$trend_kate->slug)); ?>" class="text-decoration-none text-dark">
                    <div class="card border-0">
                        <img src="<?php echo e(asset('asset/upload/kategori/'.$trend_kate->image)); ?>" class="card-img-top" alt="Produk">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($trend_kate->nama); ?></h5>
                            <p class="card-text">
                                <?php echo e($trend_kate->deskripsi); ?>

                            </p>
                        </div>
                    </div>
                    </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/luthfimeteor/lks_toko/toko/resources/views/frontend/index.blade.php ENDPATH**/ ?>