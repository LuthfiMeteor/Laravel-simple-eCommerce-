<?php $__env->startSection('main'); ?>
    <div class="card">
        <div class="card-body">
            <h1>Home</h1>
        </div>
        <?php if(session('status')): ?>
            <div class="alert alert-success" role="alert">
            <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/luthfimeteor/lks_toko/toko/resources/views/admin/index.blade.php ENDPATH**/ ?>