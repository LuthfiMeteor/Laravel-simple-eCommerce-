<?php $__env->startSection('title'); ?>
    <?php echo e($category->nama); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="py-4 mb-4 border-0 b">
        <div class="container">
            <h4 class="mb-0 text-decoration-none text-dark">
                <a href="<?php echo e(url('category')); ?>" class="text-decoration-none text-dark">Kategori</a>/
                <a href="<?php echo e(url('lihat-kategori/'.$category->nama)); ?>" class="text-decoration-none text-dark"><?php echo e($category->nama); ?></a>
            </h4>
        </div>
    </div>
     <div class="py-5">
        <div class="container">
            <div class="row">
                <h2><?php echo e($category->nama); ?></h2>
                      <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-3 mb-3">
                    <div class="card border-0">
                        <a href="<?php echo e(url('lihat-kategori/'.$category->slug.'/'.$product->slug)); ?>">
                        
                        <img src="<?php echo e(asset('asset/upload/produk/'.$product->image)); ?>" class="card-img-top" alt="Produk">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($product->nama); ?></h5>
                             <span class="float-start">Rp. <?php echo e($product->harga_jual); ?></span>
                            <span class="float-end text-danger"><s>Rp. <?php echo e($product->original_harga); ?></s></span>
                        </div>
                        </a>
                    </div>
                </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/luthfimeteor/lks_toko/toko/resources/views/frontend/produk/index.blade.php ENDPATH**/ ?>