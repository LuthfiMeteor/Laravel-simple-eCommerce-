<?php $__env->startSection('main'); ?>
    <div class="card">
        <div class="card-header">
            kategori
        </div>
        <div class="card-body">
            <form action="/edit-kategori/proses/<?php echo e($kate->id); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="">Nama</label>
                        <input type="text" class="form-control" name="nama" value="<?php echo e($kate->nama); ?>">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="">Slug</label>
                        <input type="text" class="form-control" name="slug" value="<?php echo e($kate->slug); ?>">
                    </div>
                    <div class="col-md-12 mb-3">
                        <label for="deskripsi">Deskripsi</label>
                        <textarea name="deskripsi" id="" rows="3" class="form-control" ><?php echo e($kate->deskripsi); ?></textarea>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="">Status</label>
                        <input type="checkbox" name="status" id="" <?php echo e($kate->status=="1"? 'checked':''); ?>>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="">Popular</label>
                        <input type="checkbox"  name="popular" <?php echo e($kate->popular=="1"? 'checked':''); ?>>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="">Meta Title</label>
                        <input type="text" class="form-control" name="meta_title" value="<?php echo e($kate->meta_title); ?>">
                    </div>
                    <div class="col-md-12 mb-3">
                        <label for="">Meta Keywords</label>
                        <textarea name="meta_keywords" id="" rows="3" class="form-control"><?php echo e($kate->meta_keywords); ?></textarea>
                    </div>
                    <div class="col-md-12 mb-3">
                        <label for="">Meta Deskripsi</label>
                        <textarea name="meta_deskripsi" id="" rows="3" class="form-control"><?php echo e($kate->meta_deskripsi); ?></textarea>
                    </div>
                    <div class="col-md-12">
                        <input type="file" name="image" id="" class="form-control">
                    </div>
                    <div class="col-md-12">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                    
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/luthfimeteor/lks_toko/toko/resources/views/admin/kategori/edit.blade.php ENDPATH**/ ?>