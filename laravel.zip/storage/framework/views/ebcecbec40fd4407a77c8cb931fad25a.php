<?php $__env->startSection('title', $produk->nama); ?>

<?php $__env->startSection('content'); ?>
    <div class="py-4 mb-4 border-0 b">
        <div class="container">
            <h4 class="mb-0 text-decoration-none text-dark">
                <a href="<?php echo e(url('category')); ?>" class="text-decoration-none text-dark">Kategori</a>/
                <a href="<?php echo e(url('lihat-kategori/Elektronik')); ?>" class="text-decoration-none text-dark">Elektronik</a>/
                <a href="#" class="text-decoration-none text-dark"><?php echo e($produk->nama); ?></a>
            </h4>
        </div>
    </div>
    <section class="py-0">
            <div class="container px-1 px-lg-5 my-5 produk_data">
                <div class="row gx-4 gx-lg-5 align-items-center">
                    <div class="col-md-6"><img class="card-img-top mb-5 mb-md-0" src="<?php echo e(asset('asset/upload/produk/'.$produk->image)); ?>" alt="..." /></div>
                    <div class="col-md-6">
                        <div class="float-end badge bg-danger"><?php echo e($produk->trending == '1'? 'Trending':''); ?></div><br>
                        <div class="small mb-1">slug : <?php echo e($produk->slug); ?></div>
                        <h1 class="display-5 fw-bolder"><?php echo e($produk->nama); ?></h1>
                        <div class="fs-5 mb-5">
                            <span class="text-decoration-line-through text-danger">Rp. <?php echo e($produk->original_harga); ?></span>
                            <span>Rp. <?php echo e($produk->harga_jual); ?></span>
                        </div>
                        <p class="lead"><?php echo e($produk->small_deskripsi); ?></p>
                        <div class="d-flex">
                            <input type="hidden" value="<?php echo e($produk->id); ?>" class="prod_id">
                            <button type="button" class="btn btn-secondary botder-end-0 rounded-0 decrement-btn" onclick="decrement()">-</button>
                            <input class="text-center rounded-0 qty-check" id="inputQuantity" type="num" min="0" value="1" style="max-width: 3rem" />
                            <button type="button" class="btn btn-secondary botder-end-0 rounded-0 me-3" onclick="increment()">+</button>
                            <button class="btn btn-outline-dark flex-shrink-0 me-3 increment-btn" type="button" >
                                <i class="bi-cart-fill me-1"></i>
                                Add to Wishlist
                            </button>
                            <button class="btn btn-outline-dark flex-shrink-0 tambahkeranjang" type="button" id="tambahkeranjang">
                                <i class="bi-cart-fill me-1"></i>
                                Add to cart
                            </button>
                        </div>
                    </div>
                    <div class="col-md-12 border-top mt-1">
                        <h4 class="mt-1">Deskripsi</h4>
                        <p>
                            <?php echo e($produk->deskripsi); ?>

                        </p>
                    </div>
                </div>
            </div>
        </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function() {
                $("#tambahkeranjang").click(function(e) {
                e.preventDefault();
                var produk_id = $(this).closest('.produk_data').find('.prod_id').val();
                var produk_qty = $(this).closest('.produk_data').find('.qty-check').val();
                
                    $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                    });
                    $.ajax({
                        url: "/tambah-ke-keranjang",
                        type: "POST",
                        data: {
                            'produk_id': produk_id,
                            'produk_qty':produk_qty,
                        },
                        success: function(response) {
                            console.log(response);
                        },
                        success:function(response)
                        {
                            alert(response.status);
                        }
                        });

            });
            
            });

    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/luthfimeteor/lks_toko/toko/resources/views/frontend/produk/lihat.blade.php ENDPATH**/ ?>