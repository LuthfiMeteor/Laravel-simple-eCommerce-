<?php $__env->startSection('main'); ?>
    <div class="card">
        <div class="card-header">
            kategori
        </div>
        <table class="table">
     <thead>
    <tr>
      <th scope="col">id</th>
      <th scope="col">Nama</th>
      <th scope="col">Deskripsi</th>
      <th scope="col">Image</th>
      <th colspan="2">Action</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
    <tr>
      <th scope="row"><?php echo e($kategori->id); ?></th>
      <td><?php echo e($kategori->nama); ?></td>
      <td><?php echo e($kategori->deskripsi); ?></td>
      <td><img src="asset/upload/kategori/<?php echo e($kategori->image); ?>" alt=""></td>
      <td> <a href="edit-kategori/<?php echo e($kategori->id); ?>" class="btn btn-info">Edit</a></td>
       <form action="hapus-kategori/<?php echo e($kategori->id); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('delete'); ?>
        <td class="text-center"><Input type="submit" value="Delete" class="btn btn-danger"></Input></td>
      </form>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
    <div class="d-grid">
        <a href="/tambah-kategori" class="btn btn-info">Tambah Kategori</a>
    </div>
    </div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/luthfimeteor/lks_toko/toko/resources/views/admin/kategori/index.blade.php ENDPATH**/ ?>