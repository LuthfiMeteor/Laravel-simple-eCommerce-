@extends('layouts.frontend')
@section('title')
    checkout
@endsection
@section('content')
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-7">
                <div class="card">
                    <div class="card-body">
                        <h6>Basic Detail</h6>
                    </div>
                </div>
            </div>
            <div class="col-md-5">
                <div class="card">
                    <div class="card-body">
                        Order Detail
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection